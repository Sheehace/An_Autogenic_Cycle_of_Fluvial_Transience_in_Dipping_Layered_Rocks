clear all
close all
clc





%% BLOCK 1: GEO / SIMULATION PARAMETERS

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% SIMULATION PARAMETER

iterations = 10000              % Number of random combonations of parameters 


% FIELD MEASUREMENTS

dpp_min = 1222                  % Spacing between axial streams (meters)
dpp_max = 1870

Dip_min = 3                     % Dip angle (degrees)
Dip_max = 6

BG_W_min = 10000              % Blue Gate valley width (meters, rounded to the nearest km because the western valley boundary is ambiguous...results suggest that this doesn't make a difference anyway because the valley is so much wider than dpp)
BG_W_max = 18000

TK_W_min = 600                % Tununk valley width (rounded to the nearest 100 m)
TK_W_max = 1000


% HYPOTHETICAL SAN RAFEL RIVER INCISION RATES (meters per year)

U_Pederson = 0.00045            % Pederson et al., 2013
U_Darling = 0.00004             % Darling et al., 2012           
U_SW = 0.003                    % Sheehan and Ward, 2018 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%





%% BLOCK 2: CREATE RANDOM PARAMETER COMBONATIONS

% FOR EACH OF THE 4 PARAMETERS (dpp, dip angle, and Blue Gate / Tununk valley width), 
% CREATE AN ARRAY OF LENGTH "iterations" WITH RANDOM VALUES BETWEEN THE MINIMUM AND MAXIMUM 
% VALUES MEASURED IN THE FIELD. IN THE MONTE CARLO SIMULATIONS IN BLOCKS 3 AND 4, EACH ITERATION OF THE
% RECURRENCE INTERVAL IS CALCULATED USING PARAMETER VALUES IN A COMMON
% ARRAY INDEX. NOTICE THAT THE SEED OF THE rand() FUNTION IS NOT RESET BEFORE ANY OF THE 
% INSTANCES rand() IS CALLED...THE SEED DOES NOT AUTOMATICALLY RESET WHEN
% rand() IS CALLED, AND SO PARAMETER VALUES IN A COMMON ARRAY INDEX SHOULD NOT VARY 
% SYSTEMATICALLY WITH EACH OTHER. ALTERNATIVELY, WE COULD PROVIDE EACH OF THE rand() 
% INSTANCES WITH A DIFFERENT SEED AND ACHIEVE A SIMILAR RESULT.

dpp = (dpp_max-dpp_min).*rand(iterations,1) + dpp_min;
Dip = (Dip_max-Dip_min).*rand(iterations,1) + Dip_min;
BG_Hap = (BG_W_max-BG_W_min).*rand(iterations,1) + BG_W_min;
TK_Hap = (TK_W_max-TK_W_min).*rand(iterations,1) + TK_W_min;





%% BLOCK 3: PERFORM THE CALCULATIONS USED TO CREATE TOP PANELS IN FIGURE 2d (NUMBER IN REFERENCE TO ARTICLE, NOT MATLAB FIGURE NUMBER) AND PLOT IT

% CALCULATE RECCURENCE INTERVAL "iterations"-NUMBER OF TIMES FOR EACH VALLEY 
% AND FOR EACH OF THE HYPOTHETICAL SAN RAFAEL INCISION RATES. FOR EACH ITERATION, 
% USE PARAMETER VALUES IN A COMMON ARRAY INDEX

for r = 1:iterations
    
    % BLUE GATE VALLEY
    BG_I_Pederson(r,1) = ( (dpp(r,1) * tand(Dip(r,1))) / U_Pederson ) * ( 1 - exp(-BG_Hap(r,1) / dpp(r,1)) );   % Using incision rates implied by Pederson et al., 2013
    BG_I_Darling(r,1) = ( (dpp(r,1) * tand(Dip(r,1))) / U_Darling ) * ( 1 - exp(-BG_Hap(r,1) / dpp(r,1)) );     % Using incision rates implied by Darling et al., 2012
    BG_I_SW(r,1) = ( (dpp(r,1) * tand(Dip(r,1))) / U_SW ) * ( 1 - exp(-BG_Hap(r,1) / dpp(r,1)) );               % Using incision rates implied by Sheehan and Ward, 2018
    
    % TUNUNK VALLEY
    TK_I_Pederson(r,1) = ( (dpp(r,1) * tand(Dip(r,1))) / U_Pederson ) * ( 1 - exp(-TK_Hap(r,1) / dpp(r,1)) );   % Using incision rates implied by Pederson et al., 2013
    TK_I_Darling(r,1) = ( (dpp(r,1) * tand(Dip(r,1))) / U_Darling ) * ( 1 - exp(-TK_Hap(r,1) / dpp(r,1)) );     % Using incision rates implied by Darling et al., 2012 
    TK_I_SW(r,1) = ( (dpp(r,1) * tand(Dip(r,1))) / U_SW ) * ( 1 - exp(-TK_Hap(r,1) / dpp(r,1)) );               % Using incision rates implied by Sheehan and Ward, 2018
end

% CALCULATE MEAN AND STD OF MONTE CARLO RESULTS (BLUE GATE VALLEY)
BG_I_Pederson_mean = mean(BG_I_Pederson);
BG_I_Pederson_std = std(BG_I_Pederson);
BG_I_Darling_mean = mean(BG_I_Darling);
BG_I_Darling_std = std(BG_I_Darling);
BG_I_SW_mean = mean(BG_I_SW);
BG_I_SW_std = std(BG_I_SW);

% CALCULATE MEAN AND STD OF MONTE CARLO RESULTS (TUNUNK VALLEY)
TK_I_Pederson_mean = mean(TK_I_Pederson);
TK_I_Pederson_std = std(TK_I_Pederson);
TK_I_Darling_mean = mean(TK_I_Darling);
TK_I_Darling_std = std(TK_I_Darling);
TK_I_SW_mean = mean(TK_I_SW);
TK_I_SW_std = std(TK_I_SW);

% PLOT BLUE GATE VALLEY DATA
figure(1)
hold on
errorbar(U_Pederson, BG_I_Pederson_mean, BG_I_Pederson_std, 'LineWidth', 2)
errorbar(U_Darling, BG_I_Darling_mean, BG_I_Darling_std, 'LineWidth', 2)
errorbar(U_SW, BG_I_SW_mean, BG_I_SW_std, 'LineWidth', 2)
set(gca, 'YScale', 'log')
set(gca, 'XScale', 'log')
title('Blue Gate Strike Valley');
xlabel('Hypothetical Transverse River Incision Rate (m/yr)');
ylabel('Implied I (yr)');
legend('Green River near junction with San Rafael River (since ~100 ka, Pederson et al., 2013)', 'Green River in Desolation Canyon (since ~1.5 Ma, Darling et al., 2012)', 'Gullies in Tununk Shale (since ~20 ka, Sheehan and Ward, 2018)', 'location', 'northeast');

% PLOT TUNUNK VALLEY DATA
figure(2)
hold on
errorbar(U_Pederson, TK_I_Pederson_mean, TK_I_Pederson_std, 'LineWidth', 2)
errorbar(U_Darling, TK_I_Darling_mean, TK_I_Darling_std, 'LineWidth', 2)
errorbar(U_SW, TK_I_SW_mean, TK_I_SW_std, 'LineWidth', 2)
set(gca, 'YScale', 'log')
set(gca, 'XScale', 'log')
title('Tununk Strike Valley');
xlabel('Hypothetical Transverse River Incision Rate (m/yr)');
ylabel('Implied I (yr)');
legend('Green River near junction with San Rafael River (since ~100 ka, Pederson et al., 2013)', 'Green River in Desolation Canyon (since ~1.5 Ma, Darling et al., 2012)', 'Gullies in Tununk Shale (since ~20 ka, Sheehan and Ward, 2018)', 'location', 'northeast');





%% BLOCK 4: PERFORM THE CALCULATIONS USED TO CREATE BOTTOM PANEL OF FIGURE 4d (NUMBER IN REFERENCE TO ARTICLE, NOT MATLAB FIGURE NUMBER) AND PLOT IT

% CALCULATE 2 COMMON "Hap VS I" CURVES FOR THE BLUE GATE AND TUNNUNK
% VALLEYS (USING INCISION RATES FROM DARLING 2012 AND PEDERSON 2013). WE CONSIDER A RANGE OF HYPOTHETICAL VALLEY WIDTHS (0 : 100
% : 20,000 meters). FOR EACH HYPOTHETICAL WIDTH, CALCULATE RECCURENCE INTERVAL 
% "iterations"-NUMBER OF TIMES WITH RANDOM DIP AND dpp VALUES. EXECUTE THIS
% PROCESS TWICE, ONCE FOR THE MAXIMUM AND ONCE FOR THE MINIMUM ESTIMATES FROM DARLING 2012 AND PEDERSON 2013. 

figure(4)
hold on
for x = 0:100:20000 % IN THIS CASE, "x" WILL REFLECT VALLEY WIDTH (METERS). MAXIMUM VALUE OF 20,000 WAS CHOSEN BECAUSE IT IS SLIGHTLY LARGER THAN THE MAXIMUM BLUE GATE VALLEY WIDTH. AN INTERVAL OF 100 METERS IS SOMEWHAT AMBIGUOUS BUT SERVES THE ANALYSIS WELL AND PLOTS WELL.
    
    % ENVELOPE FOR SAN RAFAEL INCISION RATE = U_Darling
        for r = 1:iterations
            I(r,1) = ( (dpp(r,1) * tand(Dip(r,1))) / U_Darling ) * ( 1 - exp(-x / dpp(r,1)) );   % ITERATIVELY CALCULATE RECCURENCE INTERVAL FOR THE GIVEN VALLEY WIDTH
        end
    
        I_mean = mean(I);   % CALCULATE MEAN AND STD OF THE LAST MONTE CARLO
        I_std = std(I);
    
        if (x > BG_W_min) && (x < BG_W_max)             % PLOT MONTE CARLO MEAN AND STD FOR THE GIVEN VALLEY WIDTH. COLOR-CODED IF WIDTH OVERLAPS WITH EITHER OF THE TWO VALLEYS
            errorbar(x, I_mean, I_std, 'g')
        elseif (x > TK_W_min) && (x < TK_W_max)
            errorbar(x, I_mean, I_std, 'r')
        else errorbar(x, I_mean, I_std, 'k')
        end
    
    % ENVELOPE FOR U = U_Pederson
        for r = 1:iterations
            I(r,1) = ( (dpp(r,1) * tand(Dip(r,1))) / U_Pederson ) * ( 1 - exp(-x / dpp(r,1)) );   % ITERATIVELY CALCULATE RECCURENCE INTERVAL FOR THE GIVEN VALLEY WIDTH
        end
    
        I_mean = mean(I);   % CALCULATE MEAN AND STD OF THE LAST MONTE CARLO
        I_std = std(I);
    
        if (x > BG_W_min) && (x < BG_W_max)             % PLOT MONTE CARLO MEAN AND STD FOR THE GIVEN VALLEY WIDTH. COLOR-CODED IF WIDTH OVERLAPS WITH EITHER OF THE TWO VALLEYS
            errorbar(x, I_mean, I_std, 'g')
        elseif (x > TK_W_min) && (x < TK_W_max)
            errorbar(x, I_mean, I_std, 'r')
        else errorbar(x, I_mean, I_std, 'k')
        end
end
    
title('Blue Gate (green) and Tununk (red) Valleys');
xlabel('W (meters)');
ylabel('T (yrs)');
set(gca, 'YScale', 'log')





%% BLOCK 5: CLEAN-UP. KEEP ONLY THE DATA PLOTTED IN FIGURE 4A,B (NUMBER IN REFERENCE TO THE PAPER, NOT MATLAB FIGURE NUMBER).

clear BG_Hap
clear BG_I_Darling
clear BG_I_Pederson
clear BG_I_SW_max
clear BG_I_SW_min
clear BG_I_Ward_max
clear BG_I_Ward_min
clear TK_Hap
clear TK_I_Darling
clear TK_I_Pederson
clear TK_I_SW_max
clear TK_I_SW_min
clear TK_I_Ward_max
clear TK_I_Ward_min
clear Dip
clear dpp
clear BG_Hap_max
clear BG_Hap_min
clear Dip_max
clear Dip_min
clear dpp_max
clear dpp_min
clear iterations
clear r
clear TK_Hap_max
clear TK_Hap_min
clear U_Darling
clear U_Pederson
clear U_SW_max
clear U_SW_min
clear U_Ward_max
clear U_Ward_min
clear I
clear I_mean
clear I_std
clear x
clear BG_I_SW
clear BG_W_max
clear BG_W_min
clear TK_I_SW
clear TK_W_max
clear TK_W_min
clear U_SW




